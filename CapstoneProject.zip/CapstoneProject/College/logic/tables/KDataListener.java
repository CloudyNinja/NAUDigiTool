/**
 * @author David Tucker
 * @version 1.2
 */

package logic.tables;

public interface KDataListener {
	public void dataChanged(KDataEvent event);
}