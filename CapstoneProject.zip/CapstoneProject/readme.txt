KMapplet package

Requires:
* Java J2SE JRE v1.2.1.004 or better (JRE v5.0 or better recommended)
* Java system requirements for JRE can be found at 'http://java.sun.com'

To Run:
* Open the 'KMapplet.html' file.
* See 'Help' section for more details on working the applet.

Notes:
*College version does not have enhanced help/tutorial files
*High School version has equations and 5 & 6 var disabled through GUI only
	(applet is still fully functional)
